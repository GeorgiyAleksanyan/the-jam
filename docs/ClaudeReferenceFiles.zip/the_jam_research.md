# The Jam - Competitive Landscape & Tech Stack Cost Analysis
## Research Document (February 2026)

---

## PART 1: LLM API COSTS (PRIORITY 1)

### Anthropic Claude (February 2026)

**Claude 4.5 Series (Current Generation - Most Cost-Effective)**

| Model | Input (per 1M tokens) | Output (per 1M tokens) | Context Window | Notes |
|-------|----------------------|------------------------|----------------|--------|
| Claude Haiku 4.5 | $1.00 | $5.00 | 200K | Fastest, most efficient |
| Claude Sonnet 4.5 | $3.00 | $15.00 | 1M (beta) | Balanced, best for coding |
| Claude Opus 4.5 | $5.00 | $25.00 | 200K | Most capable, 66% cheaper than 4.1 |

**Claude Opus 4.6 (Released Feb 5, 2026)**
- Input: $5.00/1M tokens | Output: $25.00/1M tokens
- 1M token context window (beta)
- Agent teams, compaction, adaptive thinking
- Promotional $50 in free usage credits for existing subscribers (until Feb 16)

**Legacy Models (Higher Cost)**
- Claude Opus 4.1: $15/$75 per 1M tokens
- Claude Opus 4: $15/$75 per 1M tokens

**Cost Optimization Features:**
- **Prompt Caching**: 90% savings on repeated context (cache reads: 10% of base price)
- **Batch API**: 50% discount for non-urgent workloads
- **Extended Thinking**: Charged at output token rates (minimum 1,024 token budget)

**Consumer Pricing (claude.ai):**
- Free: Limited daily use
- Pro: $20/month (or $17/month annually)
- Max: $100-$200/month (5x-10x Pro capacity)
- Team: Premium seats at $100/month (annual) with Max-level usage
- Enterprise: Custom pricing ($500-15,000+/month)

---

### OpenAI (February 2026)

**GPT-5 Family (Flagship - Latest Generation)**
| Model | Input (per 1M tokens) | Output (per 1M tokens) | Context Window |
|-------|----------------------|------------------------|----------------|
| GPT-5 | $1.25 | $10.00 | N/A |
| GPT-5 Mini | $0.25 | $2.00 | N/A |
| GPT-5 Nano | $0.05 | $0.40 | N/A |

**GPT-4.1 Family**
- GPT-4.1: $2.00/$8.00 per 1M tokens (1M context)
- GPT-4.1 Mini: Input pricing varies

**GPT-4o Family (Multimodal)**
- GPT-4o: $2.50/$10.00 per 1M tokens (128K context)
- GPT-4o Mini: $0.15/$0.60 per 1M tokens (128K context)

**O-Series (Reasoning Models)**
- O1: $15/$60 per 1M tokens
- O1-mini: Pricing varies
- O3, O3-mini, O4-mini: Available in select tiers

**Legacy Models**
- GPT-4 Turbo: $30/$60 per 1M tokens (8K context)

**Pricing Tiers:**
- Batch: 50% off (non-urgent, 24hr processing)
- Flex: Variable latency, lower cost
- Standard: Normal pricing
- Priority: 2x cost for <50ms latency

**Consumer Pricing:**
- ChatGPT Plus: $20/month
- ChatGPT Pro: $200/month (enhanced reasoning)
- ChatGPT Enterprise: Custom pricing (SOC 2, SSO, dedicated support)

**Free Credits:** $5 for new API accounts (expires in 3 months)

---

### Google Gemini (February 2026)

**Gemini 3 Family (Latest - Preview)**
| Model | Input (per 1M tokens) | Output (per 1M tokens) | Context Window |
|-------|----------------------|------------------------|----------------|
| Gemini 3 Pro Preview | $2.00 ($4.00 >200K) | $12.00 ($18.00 >200K) | 1M |
| Gemini 3 Flash Preview | $0.50 | $3.00 | 1M |

**Gemini 2.5 Family (Stable Production)**
- Gemini 2.5 Pro: $1.25/$10.00 per 1M tokens ($2.50/$18.00 for >200K context)
- Gemini 2.5 Flash: $0.075/$0.60 per 1M tokens (hybrid reasoning)
- Gemini 2.5 Flash-Lite: $0.10/$0.40 per 1M tokens

**Gemini 2.0 Family**
- Gemini 2.0 Flash: Pricing varies
- Gemini 2.0 Flash-Lite: Budget option

**Special Features Pricing:**
- Google Search Grounding:
  - Gemini 3: $14/1K queries
  - Gemini 2.x: $35/1K prompts
  - 500-1,500 RPD free depending on tier
- Google Maps Grounding: $25/1K prompts
- Image Generation (Imagen): $0.039-$0.24 per image
- Video Generation (Veo): Per-second pricing
- TTS Audio: $30 per 1M tokens

**Cost Optimization:**
- Batch API: 50% off
- Context Caching: 90% savings (cache storage: $1-4.50/1M tokens/hour)
- Free tier: Very generous (1.5 Pro, 2.5 Flash models with rate limits)

**Consumer Pricing:**
- Free: Gemini Basic
- Pro: $19.99/month
- Ultra: $124.99/3 months (Veo 3.1, Gemini 2.5 Deep Think, 25K AI credits)
- Enterprise: Custom (through Workspace)

---

## PART 2: AI AGENT PLATFORM COMPETITORS

### 1. Lindy.ai

**Pricing (2026):**
- Free: $0/month, 400 credits
- Pro: $49.99/month, 5,000+ credits
- Business: $299.99/month, 30,000+ credits
- Enterprise: Custom pricing

**Credit System:**
- Simple tasks: 1 credit
- Email sending: 7 credits
- Knowledge base search: 3 credits
- Phone calls: ~265 credits per call
- Complex tasks: Variable (more credits for premium models)

**Additional Costs:**
- Extra credits: $10 per 1,000
- Phone capabilities: $0.19/minute
- Premium models (GPT-4, Claude Opus): Higher credit burn rate

**What It Does:**
- No-code AI agent builder (drag-and-drop interface)
- 5,000+ business integrations
- Multi-channel: Email, phone, chat, Slack, etc.
- Computer Use: Browser automation beyond APIs
- Agent Builder: Natural language agent creation
- Lindy Build: Autonomous app building with testing

**Target Market:** Growing businesses, operations teams, sales/support

**Strengths:**
- Easy to use, no coding required
- Huge integration library
- Multi-channel capabilities
- SOC 2, HIPAA, GDPR compliant

**Weaknesses:**
- Credit-based pricing can be unpredictable
- Credits deplete faster than expected for complex workflows
- Voice/telephony can be expensive at scale
- Example: Lead gen campaign (search + email + call) = 275 credits = only 18 leads on Pro plan

**User Feedback:**
- Praised for interface and ease of use
- Criticized for credit consumption transparency
- Phone calling adds up quickly for high-volume use

---

### 2. Relevance AI

**Pricing (2026):**
- Free: $0/month
  - 200 Actions/month
  - 1,000 Vendor Credits (one-time)
  - 1 user, 10MB knowledge storage
- Pro: $19/month
  - 2,500 Actions/month (updated from 10,000)
  - 3,000 Vendor Credits/month
  - 1 user, 100MB knowledge storage
  - Bulk runs, scheduled runs, chat support
- Team: $199/month
  - 10,000 Actions/month (updated from 100,000)
  - Vendor Credits included
  - 10 users, 1GB knowledge storage
  - Premium integrations (LinkedIn, WhatsApp)
  - Priority support
- Business: $599/month
  - Higher Action limits
  - More users and storage
  - Advanced features
- Enterprise: Custom pricing
  - Unlimited potential
  - Dedicated account manager
  - SOC 2 Type II compliant

**Pricing Structure:**
- **Actions:** Unit of work an agent performs (1 action regardless of complexity)
- **Vendor Credits:** Pass-through AI model costs at wholesale prices
  - Unused credits roll over indefinitely while subscription active
- **Fixed execution cost:**
  - Free/Pro: 4 credits per execution
  - Team: 3 credits per execution  
  - Business: 2 credits per execution
- **Variable cost:** Based on compute time and model used

**What It Does:**
- Low-code AI agent builder
- Build AI "workforce" - multiple agents working together
- 9,000+ tool integrations
- Marketplace with 400+ pre-built agents
- Knowledge storage for context
- API integrations for CRMs, databases, apps

**Target Market:** Mid to large businesses, operations/sales/marketing teams

**Strengths:**
- Transparent pricing (though some say complex)
- Wholesale AI model pricing (no markup)
- Huge tool library
- SOC 2 Type II compliant
- Generous free tier to test

**Weaknesses:**
- Pricing complexity (Actions + Vendor Credits confusing for some)
- Essential features locked behind higher tiers
- More expensive than some competitors for SMBs
- Some users report it's pricey relative to value

**Note:** Pricing appears to have changed significantly recently (credits reduced from previous levels)

---

### 3. Other Notable Competitors (To Research Further)

**Zapier Central** - AI assistant in automation platform
**Dust.tt** - Enterprise AI assistants  
**CustomGPT.ai** - Custom ChatGPT-like bots
**Botpress** - Conversational AI platform
**Voiceflow** - AI agent builder
**Kore.ai** - Enterprise virtual assistants
**Yellow.ai** - Conversational AI
**Rasa** - Open source + enterprise
**MultiOn** - Browser automation agents
**AgentGPT** - Autonomous AI agents
**AutoGPT** - Self-directed AI agents
**LangChain Cloud** - Hosted LangChain
**CrewAI** - Multi-agent orchestration
**Autogen** - Microsoft's agent framework
**Flowise** - Visual LLM app builder

---

## PART 3: WHATSAPP BUSINESS API COSTS (PRIORITY 3)

### Pricing Model (Effective January 1, 2026)

**Per-Message Pricing** (replaced conversation-based model)

**Message Categories & Rates:**

| Category | US/North America | India | Europe (High) | Notes |
|----------|-----------------|--------|---------------|-------|
| Marketing | $0.1365 | $0.025 | ~$0.20+ | Promotions, offers |
| Utility | $0.0456 | $0.004 | ~$0.05 | Order updates, confirmations |
| Authentication | $0.0456 | $0.004 | ~$0.05 | OTPs, verification |
| Service | FREE | FREE | FREE | Within 24hr window |

**Key Features:**

1. **24-Hour Customer Service Window:**
   - Opens when customer messages you
   - Resets with each new customer message
   - All responses FREE during this window (free-form messages and utility templates)
   - Potentially unlimited free messaging if customer keeps responding

2. **72-Hour Free Window:**
   - Messages from Click-to-WhatsApp ads
   - Messages from Facebook Page CTA buttons
   - ALL messages free for 72 hours after entry

3. **Volume Tiers:**
   - Higher monthly volume = lower per-message cost
   - Tiers reset monthly
   - Applies across all message types

**Regional Pricing Highlights:**
- India: Very cheap ($0.025 marketing, $0.004 utility)
- Pakistan/UAE: Similar to India
- Colombia: Low cost
- Germany/France/UK: High cost ($0.15-$0.25+ for marketing)
- US/North America: Mid-high cost ($0.1365 marketing)

**Total Cost Components:**
1. Meta's per-message fees (above)
2. BSP (Business Solution Provider) fees
3. Conversation management software

**BSP Costs:**
- Some BSPs add 15-20% markup
- Some charge setup fees, hosting fees
- Some charge per-number fees
- Best BSPs: Pass-through pricing at Meta's exact rates
  - Examples: Spur, 360Dialog, WeTarseel (no markup)
  - Platform fees: $39-499/month for software

**Example Platforms:**
- Spur: $39/month+ (AI Start tier) + Meta's exact rates
- WeTarseel: Transparent monthly plans + Meta rates
- Authkey, WappBiz, Green Ads Global: Various tiers starting ~$30-90/month

**Indian Market Specific:**
- Starter plans: ₹899/month (~$11)
- Basic plans: ₹2,499/month (~$30)
- Plus Meta's per-message charges

**Cost Optimization Strategies:**
1. Respond immediately when customers message (free 24hr window)
2. Use utility templates within customer service window (free)
3. Focus on authentication/utility vs. marketing (75-90% cheaper)
4. Leverage 72hr free window from ads
5. Build volume to unlock tier discounts
6. Choose BSP with no markup

**Example Campaign Cost:**
- 10,000 marketing messages to India: ~$250 (Meta fees only)
- 10,000 marketing messages to Germany: ~$2,200 (Meta fees only)
- 10,000 marketing messages to US: ~$1,365 (Meta fees only)

**2026 Updates:**
- Local currency billing rolling out (India: Jan 2026, Brazil: H2 2026)
- More markets getting local billing throughout year
- Marketing message costs increased in some regions
- Utility/authentication costs optimized (often cheaper)

---

## PART 4: TYPICAL AGENT TOKEN USAGE ESTIMATES

Based on research, typical AI agent monthly token usage:

**Light Use:** 10K-100K tokens/month
- Simple chatbot responses
- Basic task automation
- Limited interactions

**Medium Use:** 100K-1M tokens/month
- Active customer service agent
- Regular workflow automation
- Multi-step processes

**Heavy Use:** 1M-10M tokens/month
- 24/7 operations
- Complex multi-agent systems
- High-volume interactions

**Example Monthly Costs at Medium Use (100K tokens):**

Using Claude Haiku 4.5 (cheapest quality option):
- Input: 50K tokens × $1/1M = $0.05
- Output: 50K tokens × $5/1M = $0.25
- **Total: $0.30/month**

Using Claude Sonnet 4.5 (balanced):
- Input: 50K tokens × $3/1M = $0.15
- Output: 50K tokens × $15/1M = $0.75
- **Total: $0.90/month**

Using GPT-4o Mini (cheapest OpenAI):
- Input: 50K tokens × $0.15/1M = $0.0075
- Output: 50K tokens × $0.60/1M = $0.03
- **Total: $0.0375/month**

Using Gemini 2.5 Flash-Lite (cheapest quality):
- Input: 50K tokens × $0.10/1M = $0.005
- Output: 50K tokens × $0.40/1M = $0.02
- **Total: $0.025/month**

**Key Insight:** LLM costs are surprisingly cheap for individual agents at moderate usage. The real cost drivers will be:
1. Compute/hosting (if always-on)
2. Messaging platform fees (WhatsApp, etc.)
3. Development/platform fees
4. Storage and bandwidth

---

## RESEARCH STATUS & NEXT STEPS

### Completed:
✅ LLM API costs (Claude, OpenAI, Gemini)
✅ Top competitors pricing (Lindy, Relevance AI)
✅ WhatsApp Business API costs
✅ Token usage estimates

### Still Needed:
🔄 Cloud compute costs (AWS, GCP, Azure, DigitalOcean, Hetzner, OCI)
🔄 Additional competitor deep-dives (Dust, Botpress, Voiceflow, etc.)
🔄 Marketplace/gig economy comparisons (Fiverr, Upwork rates)
🔄 Database costs (Supabase, PostgreSQL, Redis)
🔄 Email/SMS costs (Twilio, Postmark, etc.)
🔄 Technical stack research (frameworks, architecture)
🔄 Market sizing data (TAM, growth projections, funding)
🔄 Pricing strategy recommendations

---

## PRELIMINARY INSIGHTS

### What We're Learning:

1. **LLM Costs Are Not the Main Concern:**
   - Even heavy users might only spend $5-50/month on tokens per agent
   - This is negligible compared to platform/hosting costs
   - Competitors likely losing money on free tiers or have thin margins on entry plans

2. **WhatsApp Can Be a Major Cost:**
   - If targeting US/Europe: $0.10-$0.20+ per marketing message
   - 1000 messages/day = $3,000-6,000/month in WhatsApp fees alone
   - Free 24hr window is critical for profitability
   - India/emerging markets much more economical

3. **Competitor Pricing Patterns:**
   - Entry tier: $10-50/month (Relevance $19, Lindy $50)
   - Mid tier: $200-300/month
   - Enterprise: Custom, likely $500-15,000+
   - All use usage-based caps (credits, actions, etc.)

4. **Credit-Based Pricing Creates Uncertainty:**
   - Users consistently complain about unpredictable costs
   - Credits burn faster than expected
   - Phone/voice features especially expensive
   - Need transparent, predictable pricing

5. **Market Positioning Opportunity:**
   - Most competitors target general automation
   - Specialized "AI developer agents" is unique angle
   - Crypto bounty marketplace is differentiator  
   - Could price higher due to specialized value prop

---

## PART 5: CLOUD COMPUTE COSTS (PRIORITY 4)

### AWS EC2

**t3.medium (2 vCPU, 4GB RAM) - Good for 1-2 agents**
- On-Demand: $0.0416/hour = **$30.37/month** (US East)
- Reserved (1-year): ~$18.25/month (40% savings)
- Reserved (3-year): Even cheaper
- Includes: 20GB SSD by default
- Additional storage (EBS): $0.08/GB-month

**t3.large (2 vCPU, 8GB RAM)**
- On-Demand: ~$60/month
- Reserved: ~$36/month

**t3a.medium (AMD, 2 vCPU, 4GB RAM) - 10% cheaper**
- On-Demand: $0.0376/hour = **$27.45/month**

**Total Monthly Cost Example (t3.medium):**
- Compute: $30.37
- Storage (50GB): $4.00
- Data transfer (50GB out): $4.50
- **Total: ~$39/month**

---

### Google Cloud Platform (GCP)

**e2-medium (2 vCPU, 4GB RAM)**
- Standard: ~$25-30/month (varies by region)
- Preemptible: ~$7-10/month (can be terminated)
- Committed use (1-year): ~$18/month

**Advantages:**
- Free tier: e2-micro (0.25-2 vCPU, 1GB) free 720 hours/month
- Automatic sustained use discounts
- Per-second billing

---

### Microsoft Azure

**B2s (2 vCPU, 4GB RAM)**
- Pay-as-you-go: ~$30-40/month
- Reserved (1-year): ~$20/month

**Advantages:**
- Integration with Microsoft ecosystem
- Per-second billing

---

### DigitalOcean (Developer-Friendly)

**Basic Droplets**
- 2 vCPU, 2GB RAM: **$18/month**
- 2 vCPU, 4GB RAM: **$24/month**
- 4 vCPU, 8GB RAM: **$48/month**

**Advantages:**
- Simple, predictable pricing
- No hidden costs
- Developer-friendly UI
- Excellent documentation
- Starting at $4/month for smallest

**Additional Costs:**
- Backups: +20% of droplet cost
- Managed Databases: Starting at $15/month
- Spaces (object storage): $5/month for 250GB
- Load Balancers: $12/month

---

### Hetzner (Budget Option - EU Focus)

**Cloud Servers (CPX line)**
- CPX11 (2 vCPU, 2GB RAM): **€4.51/month** (~$5/month)
- CPX21 (3 vCPU, 4GB RAM): **€8.21/month** (~$9/month)
- CPX31 (4 vCPU, 8GB RAM): **€13.90/month** (~$15/month)

**Advantages:**
- Extremely competitive pricing (cheapest option)
- 20TB traffic included (EU servers)
- Good hardware specs
- GDPR compliant
- Data centers: Germany, Finland, USA, Singapore

**Disadvantages:**
- Limited global presence
- UI not as polished
- Support not as strong
- Best for EU users (latency elsewhere)

---

### Oracle Cloud Infrastructure (OCI)

**Always Free Tier:**
- 4 ARM vCPU, 24GB RAM: **FREE forever**
- 2 AMD VMs (1/8 vCPU each, 1GB each): FREE
- 200GB block storage: FREE
- 10GB object storage: FREE

**Paid:**
- Competitive with AWS/GCP
- Pay-as-you-go or committed

**Advantages:**
- Generous free tier
- Good for testing
- Enterprise features

**Disadvantages:**
- Smaller ecosystem
- Fewer regions
- Less developer-friendly

---

### Vultr

**Regular Performance**
- 2 vCPU, 4GB RAM: **$18/month**
- 2 vCPU, 8GB RAM: **$36/month**

**Advantages:**
- 32+ global locations
- NVMe SSD storage
- Good performance
- Similar to DigitalOcean

---

### Linode (Akamai Cloud)

**Shared CPU**
- 2 vCPU, 4GB RAM: **$24/month**
- 4 vCPU, 8GB RAM: **$48/month**

**Advantages:**
- 11 global data centers
- Transparent pricing
- Strong community
- Good performance/price ratio

---

### Railway, Render, Fly.io (PaaS Options)

**Railway:**
- $5/month base
- Pay for compute usage
- ~$20-50/month for always-on service
- Git-based deployment

**Render:**
- Free tier available
- Starter: $7/month per service
- Standard: $25/month per service

**Fly.io:**
- Free tier: 3 shared VMs
- Paid: Usage-based, ~$20-40/month typical

**Advantages:**
- Easy deployment
- Auto-scaling
- Zero DevOps
- Great DX

**Disadvantages:**
- Can get expensive at scale
- Less control
- Vendor lock-in

---

## COMPUTE COST SUMMARY

| Provider | Instance Type | vCPU | RAM | Monthly Cost | Notes |
|----------|--------------|------|-----|--------------|-------|
| **Hetzner** | CPX21 | 3 | 4GB | ~$9 | 🏆 Cheapest, EU-focused |
| **OCI** | ARM | 4 | 24GB | $0 | 🏆 Best free tier |
| **DigitalOcean** | Basic | 2 | 4GB | $24 | 🏆 Best UX, predictable |
| **Linode** | Shared | 2 | 4GB | $24 | Good balance |
| **Vultr** | Regular | 2 | 4GB | $18 | Good global reach |
| **AWS** | t3.medium | 2 | 4GB | $30 | Industry standard |
| **GCP** | e2-medium | 2 | 4GB | $25-30 | Good for GCP ecosystem |
| **Azure** | B2s | 2 | 4GB | $30-40 | Best for MS shops |

**Recommendations:**
- **Cheapest:** Hetzner CPX21 @ ~$9/month (or OCI free tier for testing)
- **Best Value:** DigitalOcean @ $24/month (ease of use + predictability)
- **Production:** AWS t3.medium @ $30/month (reliability + ecosystem)

**Multiple Agents:**
- 1-2 agents: 2 vCPU, 4GB RAM (~$9-30/month)
- 3-5 agents: 4 vCPU, 8GB RAM (~$15-48/month)
- 5-10 agents: 8 vCPU, 16GB RAM (~$50-100/month)
- 10+ agents: Consider containerization (K8s) or serverless

---

## PART 6: MARKET SIZING & TAM

### AI Agent Market Size

**2025 (Current):**
- Global market: $7.6-7.9 billion
- US market: $2.2 billion

**2026 Projections:**
- Global: $10.9-11.0 billion
- CAGR: 45-50%

**2030 Projections:**
- Global: $50-53 billion (conservative estimates)
- Global: $182-236 billion (aggressive estimates)

**2033 Projections:**
- Global: $182-236 billion
- US: $46-69 billion

### Key Growth Metrics

**Adoption Rates:**
- 35% of organizations have broad AI agent usage
- 27% experimenting or limited use
- 17% company-wide deployment
- 96% of enterprises plan to expand AI agent use in next 12 months

**Enterprise Application Integration:**
- 2025: <5% of enterprise apps include AI agents
- 2026: 40% projected (Gartner)
- 2030: 80% projected

**Agent Count Projections:**
- 2028: 1.3 billion AI agents globally (projected)
- Controversial "1 billion by 2026" claims (speculative, not confirmed)

### Economic Value

**ROI & Impact:**
- $450 billion in economic value by 2028 (cost savings + revenue)
- 62% of companies investing in AI agents expect 100% ROI
- 60% increase in productivity (marketing experiments)
- 40% productivity increase expected (finance, Deloitte)
- 25% cost reduction expected (finance teams)

### Market Segmentation

**By Technology (2025):**
- Machine Learning: 30.56% share (dominant)
- Deep Learning: Fastest growth segment
- NLP, Computer Vision, other

**By Agent System:**
- Single-agent systems: 59.24% share (2025)
- Multi-agent systems: 48.5% CAGR (fastest growing)

**By Application:**
- Cognitive agents (virtual assistants): 34% share
- Customer service: Leading use case
- Operations: Top function for future deployment (36%)
- Sales & Marketing: 33-36% adoption

**By Industry:**
- Enterprise: Largest segment
- BFSI (Banking/Finance): Largest end-user
- Industrial: 49.2% CAGR (fastest growing)
- Professional services: Fastest-growing end-user
- Healthcare, Manufacturing, Supply Chain: Growing

**By Geography:**
- North America: 39.63-46% market share (dominant)
- US: 29.2% of global market
- Asia Pacific: Fastest growth region (India, China, Japan)
- Europe: Focus on compliance (GDPR, AI Act)

### Competitive Landscape - Recent Funding

While specific 2026 funding data wasn't found, the ecosystem includes:
- **400+ AI agent startups** mapped by CB Insights (Nov 2025)
- Major players: OpenAI, Google, Anthropic, Microsoft
- Enterprise platforms: Salesforce (Agentforce), ServiceNow, IBM Watson
- Specialized: Lindy, Relevance AI, Dust, Voiceflow, etc.

### Market Validation

**Pricing Validated:**
- Consumer AI subscriptions: $20/month (ChatGPT Plus, Claude Pro)
- Premium consumer: $100-200/month
- Business entry: $50-200/month
- Enterprise: $500-15,000+/month

### Risk Factors & Challenges

**Adoption Barriers:**
- 60% of organizations don't fully trust AI agents
- Confidence in autonomous agents dropped from 43% (2024) to 22% (2025)
- 61% report employee anxiety about job displacement
- 40% of agentic AI projects at risk of cancellation by 2027
- Only 16% have formal AI agent strategy/roadmap

**Key Success Factors:**
- Governance and observability
- ROI clarity
- Avoiding "agent-washing" (over-promising)
- Human-in-the-loop oversight (standard in 2026)
- Managing tooling maturity and memory management

---

## PART 7: TOTAL COST OF OWNERSHIP (TCO) PER AGENT

### Cost Model - Medium Usage (100K tokens/month)

**Scenario: One AI Agent (24/7 Available)**

| Cost Component | Conservative | Mid-Range | Premium |
|----------------|-------------|-----------|----------|
| **LLM API** | $0.03 (GPT-4o Mini) | $0.30 (Claude Haiku) | $2.00 (Claude Sonnet) |
| **Compute** | $9 (Hetzner) | $24 (DigitalOcean) | $30 (AWS t3.medium) |
| **Database** | $0 (shared Supabase free) | $5 (Upstash Redis) | $15 (Managed Postgres) |
| **Storage** | $1 (10GB) | $2 (25GB) | $5 (100GB) |
| **Bandwidth** | $2 (20GB) | $4 (50GB) | $8 (100GB) |
| **Messaging** | $0 (free windows) | $50 (1K WhatsApp/mo) | $200 (5K WhatsApp/mo) |
| **Monitoring** | $0 (basic) | $5 (Sentry/logging) | $20 (Full stack) |
| **TOTAL/month** | **$12** | **$90** | **$280** |

### Cost at Different Usage Levels

**Light Use (10K tokens/month):**
- LLM: $0.003 - $0.20
- Total: $10 - $75/month

**Medium Use (100K tokens/month):**
- LLM: $0.03 - $2.00
- Total: $12 - $280/month

**Heavy Use (1M tokens/month):**
- LLM: $0.30 - $20
- Total: $20 - $500/month

**Very Heavy Use (10M tokens/month):**
- LLM: $3 - $200
- Total: $50 - $1,000+/month

### Key Cost Insights

1. **LLM Costs Are Surprisingly Low:**
   - Even heavy users: $3-20/month per agent
   - Not the main cost driver at moderate scale

2. **Compute Is Significant:**
   - 24/7 hosting: $9-30/month minimum
   - Can't avoid if agents need to be always-on
   - Multiple agents can share one server

3. **Messaging Can Dominate:**
   - WhatsApp in US/EU: $0.10-$0.20 per marketing message
   - 1000 messages = $100-200
   - Can easily exceed all other costs combined
   - Free 24hr windows critical

4. **Database/Storage Minimal:**
   - Usually <$10/month
   - Free tiers often sufficient

5. **Economies of Scale:**
   - 1 agent on dedicated server: $30/month compute
   - 5 agents on same server: $6/month compute per agent
   - 10 agents on same server: $3/month compute per agent

---

## PART 8: PRICING STRATEGY RECOMMENDATIONS

### Competitive Positioning Analysis

**Market Price Points:**

| Tier | Competitor Range | What's Included |
|------|-----------------|-----------------|
| **Free** | $0 | Limited credits/usage, basic features |
| **Starter** | $19-50/month | 5K-10K credits, 1 user, basic agents |
| **Pro** | $199-300/month | Higher limits, team features, priority support |
| **Business** | $599+/month | Advanced features, more users, SLA |
| **Enterprise** | $500-15K+/month | Custom, unlimited, dedicated support |

### The Jam's Unique Value Props

1. **Crypto Bounty Marketplace** - Unique differentiator
2. **AI Developer Agents** - Specialized vertical
3. **Rent-to-Own Model** - New business model
4. **Competition Platform** - Gamification element

### Recommended Pricing Strategy

#### **Option A: Differentiated Premium Pricing**

**Free Tier**
- 200 credits/month
- Access to coding competitions (view only)
- 1 basic agent trial (24hr limited)
- Community access
- **Goal:** Lead generation, community building

**Developer ($29/month)**
- 2,500 credits/month
- Enter coding competitions
- Win crypto bounties
- Rent 1 AI agent (basic tier)
- Discord/Telegram integration
- **Target:** Individual developers

**Pro ($99/month)**
- 10,000 credits/month
- Host coding competitions
- Create custom bounties
- Rent up to 3 AI agents
- WhatsApp Business integration
- Priority support
- **Target:** Freelancers, small teams

**Team ($299/month)**
- 50,000 credits/month
- Up to 10 users
- Rent up to 10 AI agents
- Custom agent training
- Advanced analytics
- API access
- **Target:** Development agencies, startups

**Enterprise (Custom)**
- Unlimited credits
- Dedicated agents (owned, not rented)
- Custom competition platform
- White-label options
- SLA + dedicated support
- **Target:** Large companies, VCs

#### **Option B: Usage-Based + Base**

**Base Platform Fee: $49/month**
- Includes basic access
- Pay-per-agent: $15/agent/month
- Pay-per-competition: $5/competition
- Bounty pool: 10% platform fee

**Rationale:**
- More predictable than pure credits
- Scales with actual usage
- Similar to AWS/GCP model

### Recommended: Hybrid Approach

**Base: $49/month** (or $39 to undercut Lindy)
- Platform access
- Competition hosting
- 5 agent-hours/month included

**Add-Ons:**
- Additional agents: $10/agent/month
- Premium agents (GPT-4, Claude Opus): $25/agent/month
- WhatsApp integration: $20/month + usage
- Extra credits: $10/1000 credits
- Phone capability: $0.19/minute

**Bounty Marketplace:**
- Platform takes 5-10% of bounty pool
- Lower than typical marketplace (Fiverr/Upwork: 20%)
- Attracts more participants

### Pricing Comparison

| Feature | The Jam (Proposed) | Lindy | Relevance AI |
|---------|-------------------|-------|--------------|
| **Entry** | $49/mo | $50/mo | $19/mo |
| **Credits** | Usage-based | 5,000 | 2,500 Actions |
| **Agents** | Unlimited (pay per agent) | Limited by credits | Limited by credits |
| **Unique** | Crypto bounties | Phone/computer use | Wholesale AI pricing |
| **WhatsApp** | $20/mo addon | Included in credits | Premium tier |

### Key Differentiators

1. **Transparent Agent Pricing:** $10-25/agent vs credit confusion
2. **Bounty Marketplace:** Revenue from platform fees
3. **Developer Focus:** Not general productivity
4. **Own Your Agent:** Long-term purchase option
5. **Competition Platform:** Gamified engagement

### Margin Analysis

**Example: Pro Tier @ $99/month**

**Costs:**
- 3 agents on shared infra: $15 (compute $9 + overhead)
- LLM usage (moderate): $10
- WhatsApp (1K messages): $50
- Database/storage: $5
- Support/ops: $10
- **Total Cost: $90**
- **Gross Margin: 9%** (thin initially)

**At Scale (100 customers):**
- Shared infrastructure amortizes
- Compute cost per customer: $3-5
- **Margin improves to 50-60%**

**Revenue Streams:**
1. Monthly subscriptions
2. Bounty platform fees (5-10%)
3. Addon purchases (agents, integrations)
4. Enterprise custom deals
5. Potential: Agent marketplace (take rate)

### Pricing Psychology

✅ **Do:**
- Transparent, predictable pricing
- Simple tier names
- Clear value at each tier
- Free tier for acquisition
- Annual discount (15-20%)

❌ **Don't:**
- Confusing credit systems
- Hidden overage fees
- Bait-and-switch free tier
- Too many tiers (max 4-5)

---

## PART 9: FINAL RECOMMENDATIONS

### 1. Minimum Viable Pricing

**Launch with 3 tiers:**
- **Free:** Community + trials
- **Developer ($39/mo):** 1-2 agents, competition access
- **Pro ($99/mo):** 3-5 agents, host competitions

**Rationale:**
- Simple to understand
- Competitive with market
- Room to add tiers later

### 2. Infrastructure Stack

**Recommended for MVP:**
- **Compute:** Hetzner CPX21 ($9/mo) or DigitalOcean ($24/mo)
- **LLM:** Claude Haiku 4.5 primary ($1/$5), GPT-4o Mini fallback
- **Database:** Supabase free tier → $25/mo paid
- **Messaging:** Focus on Telegram (free API) initially
- **Storage:** Cloudflare R2 (free 10GB)
- **Monitoring:** Free tiers (Sentry, Betterstack)

**Why:**
- Keep costs <$50/mo for first 10 customers
- Prove model before scaling
- Easy to migrate later

### 3. Go-to-Market Strategy

**Phase 1: Developer Community (Months 1-3)**
- Free tier to attract developers
- Host small coding competitions
- Build agent templates
- Gather feedback

**Phase 2: Paid Conversion (Months 4-6)**
- Launch $39 and $99 tiers
- Offer annual discount (20% off)
- Add WhatsApp integration as paid addon
- Create referral program

**Phase 3: Scale & Enterprise (Months 7-12)**
- Add Team tier ($299)
- Custom enterprise deals
- Expand agent marketplace
- International expansion

### 4. Differentiation Focus

**Don't compete on:**
- General productivity (Lindy, Zapier win here)
- Lowest price (race to bottom)
- Most integrations (can't match established players)

**Do compete on:**
- **Coding agent quality** - Specialized for developers
- **Crypto bounties** - Unique motivation system
- **Competition platform** - Gamified learning
- **Own-your-agent** - Different business model
- **Developer community** - Strong moat

### 5. Critical Success Factors

✅ **Must Have:**
1. Transparent, predictable pricing
2. High-quality coding agents (better than ChatGPT Code)
3. Seamless competition experience
4. Fair bounty distribution (low platform fees)
5. Strong developer community

❌ **Avoid:**
1. Credit-based pricing confusion
2. Nickel-and-diming users
3. Overselling capabilities
4. Poor documentation
5. Slow agent performance

### 6. Realistic Projections

**Year 1 Goals:**
- 1,000 free users
- 100 paid customers ($39-99/mo)
- Monthly recurring revenue (MRR): $5,000-10,000
- Bounty platform GMV: $50,000-100,000
- Platform fee revenue: $2,500-10,000

**Key Metrics to Track:**
- Free-to-paid conversion rate (target: 3-5%)
- Churn rate (target: <5%/month)
- Customer acquisition cost (CAC)
- Lifetime value (LTV)
- LTV/CAC ratio (target: >3)

### 7. Biggest Risks

1. **LLM Cost Volatility:** Mitigate with multiple providers
2. **Competition from OpenAI/Anthropic:** Focus on niche
3. **WhatsApp Costs:** Encourage free windows, offer Telegram
4. **Developer Skepticism:** Prove value with free tier
5. **Bounty Fraud:** Strong verification system needed

---

## EXECUTIVE SUMMARY

### Market Opportunity

- **TAM:** $7.6B (2025) → $50B+ (2030), 45%+ CAGR
- **Validated Pricing:** $20-300/month subscriptions
- **Strong Demand:** 96% enterprises expanding AI agent use

### Cost Structure Reality

**Per Agent Economics:**
- LLM: $0.30-2/month (surprisingly cheap)
- Compute: $3-10/month (shared infrastructure)
- Messaging: $0-200/month (highly variable, biggest cost)
- **Total: $12-90/month** per agent at scale

### Competitive Landscape

- **General Automation:** Lindy ($50/mo), Relevance ($19-599/mo)
- **Developer Tools:** ChatGPT Code, GitHub Copilot ($10-20/mo)
- **Opportunity:** Specialized coding agents + crypto bounties

### Recommended Strategy

**Pricing:**
- Free (community + trial)
- $39/mo (1-2 agents, compete in bounties)
- $99/mo (3-5 agents, host competitions)
- Custom enterprise

**Differentiators:**
- Coding-focused (not general productivity)
- Crypto bounty marketplace (unique)
- Own-your-agent model (vs. rent-only)
- Strong developer community

**Infrastructure:**
- Start cheap: Hetzner/DigitalOcean (<$50/mo)
- Use Claude Haiku + GPT-4o Mini
- Telegram first (free), WhatsApp later
- Scale as revenue proves model

### Path to Profitability

- **Break-even:** ~50 customers @ $99/mo
- **Sustainable:** 100-200 customers + bounty fees
- **Margins:** 9% initially → 50-60% at scale
- **Timeline:** 6-12 months to profitability if executed well

---

## APPENDIX: ADDITIONAL COMPETITORS TO RESEARCH

### Still Need Deep-Dives:
- Dust.tt (Enterprise AI assistants)
- Botpress (Conversational AI platform)
- Voiceflow (AI agent builder)
- Kore.ai (Enterprise virtual assistants)
- Yellow.ai (Conversational AI)
- Rasa (Open source + enterprise)
- Zapier Central (AI assistant in automation)
- CustomGPT.ai (Custom ChatGPT-like bots)
- MultiOn (Browser automation)
- AgentGPT/AutoGPT (Autonomous agents)

### Framework Pricing:
- LangChain Cloud
- CrewAI hosted
- Autogen
- Flowise

### Upwork/Fiverr Rates:
- Typical developer hourly: $50-150/hr
- AI/ML specialists: $100-200/hr
- Platform fee: 20% typically

---

**Research Completed: February 9, 2026**
**Compiled by: Claude (Anthropic)**

*This research provides a comprehensive overview of the AI agent platform landscape, infrastructure costs, and market dynamics as of February 2026. All pricing and market data should be verified against current sources before making final business decisions.*
